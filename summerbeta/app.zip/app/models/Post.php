<?php

class Post extends \Eloquent {
	protected $fillable = [];
}