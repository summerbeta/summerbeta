<?php

class Love extends \Eloquent {
	protected $fillable = [];
}