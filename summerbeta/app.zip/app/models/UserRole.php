<?php

class UserRole extends \Eloquent {
	protected $fillable = [];
}