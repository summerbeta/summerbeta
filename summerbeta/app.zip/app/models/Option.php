<?php

class Option extends \Eloquent {
	protected $fillable = [];
}