<?php

class Optionsmeta extends \Eloquent {
	protected $fillable = [];
}